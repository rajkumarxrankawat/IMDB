# Identify the top 10 movies based on average rating.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT *
FROM movies
INNER JOIN ratings ON movie_id=id
GROUP BY movie_id
order by avg_rating desc limit 10
''', con);
print(result)