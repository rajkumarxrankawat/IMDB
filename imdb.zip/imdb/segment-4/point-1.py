# Retrieve the minimum and maximum values in each column of the ratings table (except movie_id).

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT 
	min(avg_rating),max(avg_rating),
	min(total_votes),max(total_votes),
	min(median_rating),max(median_rating)
FROM ratings
''', con);
print(result)