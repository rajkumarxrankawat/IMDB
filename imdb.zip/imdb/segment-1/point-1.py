# What are the different tables in the database and how are they connected to each other in the database?

import sqlite3
import pandas as pd

con = sqlite3.connect('../imdb.db')
excel = pd.read_excel('../imdb.xlsx',sheet_name = None)

for sheet in excel:
	if sheet=='ERD':
		continue
	print("=========================")
	print(sheet)
	print("=========================")
	print(pd.read_sql_query('pragma table_info({0})'.format(sheet), con))