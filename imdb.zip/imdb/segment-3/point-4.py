# Calculate the average duration of movies in each genre

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query("SELECT avg(duration) as avg_duration, genre FROM genre INNER JOIN movies ON movie_id=id GROUP BY genre", con);

print('Genre | Avg duration of Movies')
for row in result.iterrows():
	print('{} | {:.2f}'.format(row[1]['genre'], row[1]['avg_duration']))