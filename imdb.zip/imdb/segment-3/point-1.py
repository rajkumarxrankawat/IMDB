# Retrieve the unique list of genres present in the dataset.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
df= pd.read_sql_query("SELECT DISTINCT `genre` FROM genre", con);
print(df)
