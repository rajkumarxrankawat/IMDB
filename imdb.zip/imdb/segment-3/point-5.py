# Find the rank of the 'thriller' genre among all genres in terms of the number of movies produced.
import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
WITH record as(
	SELECT genre, RANK() OVER (ORDER BY COUNT(id) ASC) AS genre_rank
	FROM movies
	INNER JOIN genre ON id=movie_id
	GROUP BY genre
	ORDER BY genre_rank
)
SELECT genre_rank FROM record WHERE genre='Thriller'
''', con);
print('Genre `Thriller` have Rank :',result['genre_rank'][0])