# Determine the count of movies that belong to only one genre.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query("SELECT count(id) as total, genre FROM genre INNER JOIN movies ON movie_id=id GROUP BY genre limit 1", con);

for row in result.iterrows():
	print('{} | {}'.format(row[1]['genre'], row[1]['total']))