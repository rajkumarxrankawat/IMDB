# Determine the total number of movies released each year and analyse the month-wise trend

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
df= pd.read_sql_query("SELECT count(id) as Total_Movies_Produce, country FROM movies WHERE year=2019 and country in('USA','India') GROUP BY country", con);
print('Total Movies Produced in the USA or India in 2019')
for row in df.iterrows():
	print('{0} | {1}'.format(row[1]['country'], row[1]['Total_Movies_Produce']))

