# Determine the total number of movies released each year and analyse the month-wise trend

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
df= pd.read_sql_query("SELECT strftime('%m',date_published) as month, year, count(id) FROM movies group by year, month", con);
print(df)
