# analyse the genre-wise running total and moving average of the average movie duration

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT
    genre,
    AVG(duration) OVER (PARTITION BY genre ORDER BY date_published) AS running_total_avg_duration
FROM movies
INNER JOIN genre ON genre.movie_id=movies.id
INNER JOIN ratings ON ratings.movie_id=movies.id
GROUP BY genre
''', con);
print(result)
