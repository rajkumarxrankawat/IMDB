# Determine the top two production houses that have produced the highest number of hits among multilingual movies

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
WITH data AS (
    SELECT
        production_company,
        COUNT(movies.id) AS hit_count
    FROM movies
	INNER JOIN ratings ON ratings.movie_id=movies.id
    WHERE languages <> 'English' AND avg_rating > 8.0 AND production_company is not null
    GROUP BY production_company
    ORDER BY hit_count DESC
)
SELECT production_company FROM data LIMIT 2;
''', con);
print(result)
