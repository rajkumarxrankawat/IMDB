# Classify thriller movies based on average ratings into different categories

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT 
	movies.title,avg_rating,
	CASE
        WHEN avg_rating >= 9.0 THEN 'Excellent'
        WHEN avg_rating >= 8.0 AND avg_rating < 9.0 THEN 'Good'
        WHEN avg_rating >= 7.0 AND avg_rating < 8.0 THEN 'Average'
        ELSE 'Below Average'
    END AS rating_category
FROM movies
INNER JOIN genre ON genre.movie_id=movies.id
INNER JOIN ratings ON ratings.movie_id=movies.id
WHERE genre = 'Thriller'
ORDER BY avg_rating DESC
''', con);
print(result)
