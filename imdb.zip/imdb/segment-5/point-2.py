# Determine the top three directors in the top three genres with movies having an average rating > 8.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT genre, names.name, avg_rating
FROM movies
INNER JOIN genre ON movies.id=genre.movie_id
INNER JOIN ratings ON ratings.movie_id=movies.id
INNER JOIN names ON names.id=director_mapping.name_id
INNER JOIN director_mapping ON director_mapping.movie_id=movies.id
WHERE genre IN (
	SELECT genre FROM genre GROUP BY genre ORDER BY movie_id desc LIMIT 3
) AND avg_rating > 8
GROUP BY genre, names.name
ORDER BY genre, avg_rating DESC
LIMIT 3;
''', con);
print(result)