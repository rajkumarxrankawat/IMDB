# Find the top two actors whose movies have a median rating >= 8.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT names.name, median_rating
FROM movies
INNER JOIN ratings ON ratings.movie_id=movies.id
INNER JOIN names ON names.id=director_mapping.name_id
INNER JOIN director_mapping ON director_mapping.movie_id=movies.id
WHERE median_rating>=8 and names.name is not null
GROUP BY names.name
ORDER BY median_rating DESC
limit 2
''', con);
print(result)