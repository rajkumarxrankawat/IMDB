# Rank actors based on their average ratings in Indian movies released in India.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT names.name, median_rating, ROW_NUMBER() OVER(ORDER BY ratings.avg_rating desc ) as Rank
FROM movies
INNER JOIN ratings ON ratings.movie_id=movies.id
INNER JOIN names ON names.id=director_mapping.name_id
INNER JOIN director_mapping ON director_mapping.movie_id=movies.id
WHERE country='India' and names.name is not null
GROUP BY names.name
ORDER BY rank,median_rating DESC
''', con);
print(result)