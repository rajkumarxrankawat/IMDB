# Identify the top three production houses based on the number of votes received by their movies.

import pandas as pd
import sqlite3

con = sqlite3.connect('../imdb.db')
result= pd.read_sql_query('''
SELECT production_company, SUM(total_votes) as number_of_votes
FROM movies
INNER JOIN ratings ON ratings.movie_id=movies.id
GROUP BY production_company
ORDER BY number_of_votes DESC
limit 3
''', con);
print(result)